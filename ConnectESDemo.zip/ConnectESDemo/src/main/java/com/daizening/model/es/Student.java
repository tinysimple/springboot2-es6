package com.daizening.model.es;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Data
@Document(indexName = "demo", type = "student")
public class Student {
    @Id
    private Integer id;

    private String name;

    private Integer age;
}
