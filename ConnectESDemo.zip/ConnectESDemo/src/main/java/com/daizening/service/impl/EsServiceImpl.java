package com.daizening.service.impl;

import com.daizening.esDao.EsReporitory;
import com.daizening.model.es.Student;
import com.daizening.service.EsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service("esService")
public class EsServiceImpl implements EsService {

    @Autowired
    private EsReporitory esReporitory;

    @Override
    public int addStudent(Student student) {
        if (student == null) {
            student = new Student();
            student.setId(1);
            student.setName("test");
            student.setAge(11);
        }
        esReporitory.save(student);
        return 0;
    }

    @Override
    public List<Student> listAll() {
        Iterable<Student> iterable= esReporitory.findAll();
        Iterator<Student> iterator = iterable.iterator();
        List<Student> list = new ArrayList<>();
        while(iterator.hasNext()) {
            list.add(iterator.next());
        }
        return list;
    }
}
