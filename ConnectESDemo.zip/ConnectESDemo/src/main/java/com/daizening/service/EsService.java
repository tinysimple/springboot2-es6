package com.daizening.service;

import com.daizening.model.es.Student;

import java.util.List;

public interface EsService {
    int addStudent(Student student);

    List<Student> listAll();
}
