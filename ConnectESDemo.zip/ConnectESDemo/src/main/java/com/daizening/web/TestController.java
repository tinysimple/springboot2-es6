package com.daizening.web;

import com.daizening.model.es.Student;
import com.daizening.service.EsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private EsService esService;

    @GetMapping("add")
    public String add() {
        esService.addStudent(null);
        return "ok";
    }

    @GetMapping("list")
    public List list() {
        List<Student> list= esService.listAll();
        return list;
    }
}
